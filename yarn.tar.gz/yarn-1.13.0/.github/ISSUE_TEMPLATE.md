<!-- *Before creating an issue please make sure you are using the latest version of yarn.* -->

**Do you want to request a *feature* or report a *bug*?**
<!-- Is the feature a substantial feature request? Please use https://github.com/yarnpkg/rfcs -->

**What is the current behavior?**

**If the current behavior is a bug, please provide the steps to reproduce.**
<!-- If you can, provide a link to a public repository which contains the files necessary to reproduce this. -->

**What is the expected behavior?**

**Please mention your node.js, yarn and operating system version.**
