require('fs').writeFileSync('foo.txt', new Date().getTime());
