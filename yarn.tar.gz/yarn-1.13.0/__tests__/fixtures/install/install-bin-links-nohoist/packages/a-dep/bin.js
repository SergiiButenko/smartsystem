#!/usr/bin/env node
console.log('exec-a');
